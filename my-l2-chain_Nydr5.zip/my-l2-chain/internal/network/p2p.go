package network

import (
    "crypto/sha256"
    "encoding/json"
    "fmt"
    "io/ioutil"
    "log"
    "net"
    "net/http"
    "sync"
     "my-l2-chain/model"
 // 替换为实际的模块路径
)

// Message represents a generic message structure for P2P communication
type Message struct {
    Type string `json:"type"`
    Data string `json:"data"`
}

// Node represents a P2P node in the network
type Node struct {
    Address        string               `json:"address"`
    Peers          map[string]struct{}  `json:"peers"` // 存储其他节点的地址
    mu             sync.Mutex
    Blockchain     []model.Block        `json:"blockchain"`   // 存储本地区块链
    RoutingTable    map[string]*Node     // DHT 路由表
    TransactionPool []model.Transaction   `json:"transaction_pool"` // 存储链下交易
}

// Config represents the configuration for the node
type Config struct {
    Address string   `json:"address"`
    Peers   []string `json:"peers"`
}

// NewNode initializes a new P2P node
func NewNode(address string) *Node {
    return &Node{
        Address:        address,
        Peers:          make(map[string]struct{}),
        Blockchain:     make([]model.Block, 0),
        RoutingTable:   make(map[string]*Node),
        TransactionPool: make([]model.Transaction, 0),
    }
}

// Start begins listening for incoming connections
func (n *Node) Start() {
    listener, err := net.Listen("tcp", n.Address)
    if err != nil {
        log.Fatalf("Error starting node: %s\n", err)
    }
    defer listener.Close()
    log.Printf("Node started at %s\n", n.Address)

    go n.startAPIServer()

    for {
        conn, err := listener.Accept()
        if err != nil {
            log.Printf("Error accepting connection: %s\n", err)
            continue
        }
        go n.handleConnection(conn)
    }
}

// startAPIServer starts the HTTP API server
func (n *Node) startAPIServer() {
    http.HandleFunc("/peers", n.peersHandler)
    http.HandleFunc("/blockchain", n.blockchainHandler)
    http.HandleFunc("/sync", n.syncHandler) // 区块同步 API
    http.HandleFunc("/dht", n.dhtHandler)   // DHT API
    http.HandleFunc("/transactions", n.transactionsHandler) // 交易处理 API
    log.Fatal(http.ListenAndServe(":8080", nil))
}

// ConnectToPeer connects to another P2P node
func (n *Node) ConnectToPeer(peerAddress string) {
    n.mu.Lock()
    defer n.mu.Unlock()
    n.Peers[peerAddress] = struct{}{}

    conn, err := net.Dial("tcp", peerAddress)
    if err != nil {
        log.Printf("Error connecting to peer: %s\n", err)
        return
    }
    defer conn.Close()

    // 发送初始消息
    message := Message{Type: "hello", Data: n.Address}
    n.sendMessage(conn, message)

    // 更新 DHT 路由表
    n.updateRoutingTable(peerAddress)
}

// updateRoutingTable updates the DHT routing table with the new peer
func (n *Node) updateRoutingTable(address string) {
    n.RoutingTable[address] = NewNode(address)
}

// Broadcast broadcasts a message to all connected peers
func (n *Node) Broadcast(message Message) {
    n.mu.Lock()
    defer n.mu.Unlock()

    for peer := range n.Peers {
        conn, err := net.Dial("tcp", peer)
        if err != nil {
            log.Printf("Error connecting to peer %s: %s\n", peer, err)
            continue
        }
        defer conn.Close()

        n.sendMessage(conn, message)
    }
}

// sendMessage sends a message over the connection
func (n *Node) sendMessage(conn net.Conn, message Message) {
    encoder := json.NewEncoder(conn)
    if err := encoder.Encode(message); err != nil {
        log.Printf("Error sending message to %s: %s\n", conn.RemoteAddr(), err)
    }
}

// handleConnection handles incoming connections from peers
func (n *Node) handleConnection(conn net.Conn) {
    defer conn.Close()
    decoder := json.NewDecoder(conn)

    for {
        var message Message
        if err := decoder.Decode(&message); err != nil {
            log.Printf("Error decoding message: %s\n", err)
            return
        }

        log.Printf("Received message from %s: %+v\n", conn.RemoteAddr(), message)
        n.processMessage(message)
    }
}

// processMessage processes different types of messages
func (n *Node) processMessage(message Message) {
    switch message.Type {
    case "hello":
        log.Printf("Received hello from %s\n", message.Data)
    case "block":
        n.handleNewBlock(message.Data)
    case "sync":
        n.handleSync(message.Data)
    case "transaction":
        n.handleNewTransaction(message.Data)
    case "dht":
        n.handleDHT(message.Data)
    default:
        log.Printf("Unknown message type: %s\n", message.Type)
    }
}

// handleNewTransaction handles the receipt of a new transaction
func (n *Node) handleNewTransaction(data string) {
    var transaction model.Transaction
    if err := json.Unmarshal([]byte(data), &transaction); err != nil {
        log.Printf("Error unmarshalling transaction: %s\n", err)
        return
    }
    n.TransactionPool = append(n.TransactionPool, transaction)
    log.Printf("New transaction added: %+v\n", transaction)
}

// handleNewBlock handles the receipt of a new block
func (n *Node) handleNewBlock(data string) {
    var newBlock model.Block
    if err := json.Unmarshal([]byte(data), &newBlock); err != nil {
        log.Printf("Error unmarshalling block: %s\n", err)
        return
    }

    if n.validateBlock(newBlock) {
        n.Blockchain = append(n.Blockchain, newBlock)
        log.Printf("New block added: %+v\n", newBlock)
    } else {
        log.Printf("Received invalid block: %+v\n", newBlock)
    }
}

// validateBlock validates a new block
func (n *Node) validateBlock(block model.Block) bool {
    expectedHash := n.calculateHash(block.Index, block.PreviousHash, block.Data)
    return block.Hash == expectedHash
}

// calculateHash calculates the block hash
func (n *Node) calculateHash(index int, previousHash, data string) string {
    record := fmt.Sprintf("%d%s%s", index, previousHash, data)
    h := sha256.New()
    h.Write([]byte(record))
    return fmt.Sprintf("%x", h.Sum(nil))
}

// syncHandler handles the /sync API endpoint
func (n *Node) syncHandler(w http.ResponseWriter, r *http.Request) {
    n.mu.Lock()
    defer n.mu.Unlock()

    // 返回本地区块链
    json.NewEncoder(w).Encode(n.Blockchain)
}

// peersHandler handles the /peers API endpoint
func (n *Node) peersHandler(w http.ResponseWriter, r *http.Request) {
    n.mu.Lock()
    defer n.mu.Unlock()

    peers := make([]string, 0, len(n.Peers))
    for peer := range n.Peers {
        peers = append(peers, peer)
    }
    json.NewEncoder(w).Encode(peers)
}

// blockchainHandler handles the /blockchain API endpoint
func (n *Node) blockchainHandler(w http.ResponseWriter, r *http.Request) {
    n.mu.Lock()
    defer n.mu.Unlock()

    json.NewEncoder(w).Encode(n.Blockchain)
}

// dhtHandler handles the DHT requests
func (n *Node) dhtHandler(w http.ResponseWriter, r *http.Request) {
    n.mu.Lock()
    defer n.mu.Unlock()

    // 返回 DHT 路由表
    peers := make([]string, 0, len(n.RoutingTable))
    for address := range n.RoutingTable {
        peers = append(peers, address)
    }
    json.NewEncoder(w).Encode(peers)
}

// transactionsHandler handles the /transactions API endpoint
func (n *Node) transactionsHandler(w http.ResponseWriter, r *http.Request) {
    n.mu.Lock()
    defer n.mu.Unlock()

    json.NewEncoder(w).Encode(n.TransactionPool)
}

// SaveBlockchain saves the blockchain to a file
func (n *Node) SaveBlockchain(filename string) {
    data, err := json.Marshal(n.Blockchain)
    if err != nil {
        log.Printf("Error marshalling blockchain: %s\n", err)
        return
    }
    if err := ioutil.WriteFile(filename, data, 0644); err != nil {
        log.Printf("Error writing blockchain to file: %s\n", err)
    }
}

// LoadBlockchain loads the blockchain from a file
func (n *Node) LoadBlockchain(filename string) {
    data, err := ioutil.ReadFile(filename)
    if err != nil {
        log.Printf("Error reading blockchain from file: %s\n", err)
        return
    }
    if err := json.Unmarshal(data, &n.Blockchain); err != nil {
        log.Printf("Error unmarshalling blockchain: %s\n", err)
    }
}

// loadConfig loads the
