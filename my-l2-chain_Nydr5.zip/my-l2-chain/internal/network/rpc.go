package network

import (
    "encoding/json"
    "fmt"
    "io/ioutil"
    "log"
    "net/http"
    "sync"

    "my-l2-chain/model" // 更新为你的模块路径
)

// Config holds the configuration for the node
type Config struct {
    Address string `json:"address"`
    Port    int    `json:"port"`
}

// LoadConfig loads configuration from a file
func LoadConfig(filename string) (*Config, error) {
    data, err := ioutil.ReadFile(filename)
    if err != nil {
        return nil, err
    }
    var config Config
    if err := json.Unmarshal(data, &config); err != nil {
        return nil, err
    }
    return &config, nil
}

// Node represents a P2P node in the network
type Node struct {
    Address        string                     `json:"address"`
    Peers          map[string]struct{}        `json:"peers"` // 存储其他节点的地址
    mu             sync.Mutex
    Blockchain     []model.Block              `json:"blockchain"` // 存储本地区块链
    RoutingTable   map[string]*Node           // DHT 路由表
    TransactionPool []model.Transaction        // 存储链下交易
}

// NewNode initializes a new P2P node
func NewNode(config *Config) *Node {
    return &Node{
        Address:        config.Address,
        Peers:          make(map[string]struct{}),
        Blockchain:     make([]model.Block, 0),
        RoutingTable:   make(map[string]*Node),
        TransactionPool: make([]model.Transaction, 0),
    }
}

// HandleRPC handles incoming RPC requests
func (n *Node) HandleRPC(w http.ResponseWriter, r *http.Request) {
    var request RPCRequest
    decoder := json.NewDecoder(r.Body)
    if err := decoder.Decode(&request); err != nil {
        n.respondWithError(w, 400, "Invalid request")
        return
    }

    var response RPCResponse
    response.JSONRPC = "2.0"
    response.ID = request.ID

    switch request.Method {
    case "getBlock":
        var params struct {
            Index int `json:"index"`
        }
        if err := json.Unmarshal(request.Params, &params); err != nil {
            n.respondWithError(w, 400, "Invalid params")
            return
        }
        block := n.getBlock(params.Index)
        response.Result = block

    case "sendTransaction":
        var params model.Transaction
        if err := json.Unmarshal(request.Params, &params); err != nil {
            n.respondWithError(w, 400, "Invalid params")
            return
        }
        n.TransactionPool = append(n.TransactionPool, params)
        response.Result = "Transaction added"

    case "processTransactions":
        n.processTransactions()
        response.Result = "Transactions processed"

    default:
        n.respondWithError(w, 404, "Method not found")
        return
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(response)
}

// processTransactions processes off-chain transactions and adds them to the blockchain
func (n *Node) processTransactions() {
    for _, tx := range n.TransactionPool {
        // Simple validation and processing logic
        block := model.Block{
            Index:        len(n.Blockchain) + 1,
            PreviousHash: n.calculateHash(len(n.Blockchain), "", ""),
            Data:         fmt.Sprintf("Transaction from %s to %s of amount %d", tx.From, tx.To, tx.Amount),
            Hash:         "", // Hash will be computed below
        }
        block.Hash = n.calculateHash(block.Index, block.PreviousHash, block.Data)
        n.Blockchain = append(n.Blockchain, block)
    }
    n.TransactionPool = nil // Clear the transaction pool after processing
}

// getBlock retrieves a block by its index
func (n *Node) getBlock(index int) *model.Block {
    if index < 0 || index >= len(n.Blockchain) {
        return nil
    }
    return &n.Blockchain[index]
}

// Example usage
func main() {
    config, err := LoadConfig("config.json")
    if err != nil {
        log.Fatalf("Error loading config: %s\n", err)
    }

    node := NewNode(config)
    go node.Start()
    node.startAPIServer()

    select {}
}
