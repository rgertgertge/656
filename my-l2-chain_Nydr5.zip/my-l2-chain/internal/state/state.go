package main

import (
    "crypto/sha256"
    "encoding/hex"
    "fmt"
)

// MerkleNode represents a node in the Merkle tree
type MerkleNode struct {
    Hash   string
    Left   *MerkleNode
    Right  *MerkleNode
}

// MerkleTree represents the Merkle tree
type MerkleTree struct {
    Root *MerkleNode
}

// NewMerkleTree creates a new Merkle tree
func NewMerkleTree() *MerkleTree {
    return &MerkleTree{}
}

// HashData hashes the input data
func HashData(data string) string {
    hash := sha256.Sum256([]byte(data))
    return hex.EncodeToString(hash[:])
}

// Add adds a new data entry to the Merkle tree
func (tree *MerkleTree) Add(data string) {
    newNode := &MerkleNode{Hash: HashData(data)}

    if tree.Root == nil {
        tree.Root = newNode
    } else {
        tree.Root = tree.addNode(tree.Root, newNode)
    }
}

func (tree *MerkleTree) addNode(root, newNode *MerkleNode) *MerkleNode {
    if root == nil {
        return newNode
    }
    if root.Left == nil {
        root.Left = newNode
    } else if root.Right == nil {
        root.Right = newNode
        // 当左右子节点都存在时，需要重新计算父节点的哈希
        leftHash := root.Left.Hash
        rightHash := root.Right.Hash
        root.Hash = HashData(leftHash + rightHash)
    } else {
        // 如果左右子节点都满了，需要递归向上构建新的节点
        newParent := &MerkleNode{
            Hash:   "",
            Left:   root,
            Right:  nil, // 这里不需要立即设置 Right，因为它会在递归中设置
        }
        // 递归调用，将当前 root 作为新父节点的左子节点，并传入新节点作为参数
        return tree.addNode(newParent, newNode)
    }
    return root
}

// GetRootHash retrieves the root hash of the Merkle tree
func (tree *MerkleTree) GetRootHash() string {
    if tree.Root == nil {
        return ""
    }
    return tree.Root.Hash
}

// Verify checks if the data is in the Merkle tree
func (tree *MerkleTree) Verify(data string) bool {
    targetHash := HashData(data)
    return tree.verifyNode(tree.Root, targetHash)
}

func (tree *MerkleTree) verifyNode(node *MerkleNode, targetHash string) bool {
    if node == nil {
        return false
    }
    if node.Hash == targetHash {
        return true
    }
    return tree.verifyNode(node.Left, targetHash) || tree.verifyNode(node.Right, targetHash)
}

// DataStore represents the storage structure
type DataStore struct {
    Transactions *MerkleTree
    Blocks       *MerkleTree
}

// NewDataStore creates a new DataStore
func NewDataStore() *DataStore {
    return &DataStore{
        Transactions: NewMerkleTree(),
        Blocks:       NewMerkleTree(),
    }
}

// AddTransaction adds a transaction to the DataStore
func (ds *DataStore) AddTransaction(data string) {
    ds.Transactions.Add(data)
}

// AddBlock adds a block to the DataStore
func (ds *DataStore) AddBlock(blockData string) {
    ds.Blocks.Add(blockData)
}

// Main function to demonstrate functionality
func main() {
    store := NewDataStore()

    store.AddTransaction("tx1")
    store.AddTransaction("tx2")
    
    fmt.Println("Root Hash of Transactions:", store.Transactions.GetRootHash())
    fmt.Println("Verify tx1:", store.Transactions.Verify("tx1"))
    fmt.Println("Verify tx2:", store.Transactions.Verify("tx2"))
    fmt.Println("Verify tx3 (not in tree):", store.Transactions.Verify("tx3"))
}
