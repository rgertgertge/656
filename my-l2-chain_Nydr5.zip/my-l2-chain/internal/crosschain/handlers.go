package crosschain

import (
    "net/http"
    "github.com/gin-gonic/gin"
)

var bridge = NewCrossChainBridge()

func LockHandler(c *gin.Context) {
    user := c.PostForm("user")
    amount := uint64(c.PostForm("amount"))
    bridge.Lock(user, amount)
    c.JSON(http.StatusOK, gin.H{"status": "locked"})
}

func UnlockHandler(c *gin.Context) {
    user := c.PostForm("user")
    amount := uint64(c.PostForm("amount"))
    bridge.Unlock(user, amount)
    c.JSON(http.StatusOK, gin.H{"status": "unlocked"})
}

func AssetsHandler(c *gin.Context) {
    user := c.Query("user")
    lockedAmount := bridge.GetLockedAssets(user)
    c.JSON(http.StatusOK, gin.H{"lockedAssets": lockedAmount})
}
