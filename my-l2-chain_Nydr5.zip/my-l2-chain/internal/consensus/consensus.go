package network

import (
    "crypto/ecdsa"
    "crypto/elliptic"
    "crypto/rand"
    "crypto/sha256"
    "encoding/json"
    "fmt"
    "io/ioutil"
    "log"
    "math/big"
    "math/rand"
    "net"
    "net/http"
    "sync"
    "time"
)

// Message represents a generic message structure for P2P communication
type Message struct {
    Type string `json:"type"`
    Data string `json:"data"`
}

// Transaction represents a transaction in the network
type Transaction struct {
    From      string // Sender address
    To        string // Receiver address
    Amount    int    // Amount of cryptocurrency
    Signature string // Signature of the transaction
}

// Validator represents a validator in the PoS system
type Validator struct {
    Address    string               // Validator address
    Stake      int                  // Validator stake
    PrivateKey *ecdsa.PrivateKey    // Private key for signing transactions
}

// Block represents a block in the blockchain
type Block struct {
    Index        int                  `json:"index"`
    PreviousHash string               `json:"previous_hash"`
    Data         string               `json:"data"`
    Creator      string               // Block creator
    Timestamp    time.Time            `json:"timestamp"`
    Difficulty   int                  `json:"difficulty"` // Difficulty value
    Reward       int                  `json:"reward"`     // Block reward
    Hash         string               `json:"hash"`
    Votes        map[string]bool      // Store votes from validators
}

// Node represents a P2P node in the network
type Node struct {
    Address        string               `json:"address"`
    Peers          map[string]struct{}  `json:"peers"` // Store other nodes' addresses
    mu             sync.Mutex
    Blockchain     []Block              `json:"blockchain"`      // Store local blockchain
    Validators     []Validator          // Validator list
    LastBlockTime  time.Time            // Record the last block generation time
    TransactionPool []Transaction        // Store off-chain transactions
}

// Config represents the configuration for the node
type Config struct {
    Address    string      `json:"address"`
    Peers      []string    `json:"peers"`
    Validators []Validator  `json:"validators"` // Validator configuration
}

// NewNode initializes a new P2P node
func NewNode(address string, validators []Validator) *Node {
    return &Node{
        Address:        address,
        Peers:          make(map[string]struct{}),
        Blockchain:     make([]Block, 0),
        Validators:     validators,
        TransactionPool: make([]Transaction, 0),
    }
}

// Start begins listening for incoming connections
func (n *Node) Start() {
    listener, err := net.Listen("tcp", n.Address)
    if err != nil {
        log.Fatalf("Error starting node: %s\n", err)
    }
    defer listener.Close()
    log.Printf("Node started at %s\n", n.Address)

    go n.startAPIServer()

    for {
        conn, err := listener.Accept()
        if err != nil {
            log.Printf("Error accepting connection: %s\n", err)
            continue
        }
        go n.handleConnection(conn)
    }
}

// startAPIServer starts the HTTP API server
func (n *Node) startAPIServer() {
    http.HandleFunc("/peers", n.peersHandler)
    http.HandleFunc("/blockchain", n.blockchainHandler)
    http.HandleFunc("/transactions", n.transactionsHandler)
    log.Fatal(http.ListenAndServe(":8080", nil))
}

// ConnectToPeer connects to another P2P node
func (n *Node) ConnectToPeer(peerAddress string) {
    n.mu.Lock()
    defer n.mu.Unlock()
    n.Peers[peerAddress] = struct{}{}

    conn, err := net.Dial("tcp", peerAddress)
    if err != nil {
        log.Printf("Error connecting to peer: %s\n", err)
        return
    }
    defer conn.Close()

    // Send initial message
    message := Message{Type: "hello", Data: n.Address}
    n.sendMessage(conn, message)
}

// Broadcast broadcasts a message to all connected peers
func (n *Node) Broadcast(message Message) {
    n.mu.Lock()
    defer n.mu.Unlock()

    for peer := range n.Peers {
        conn, err := net.Dial("tcp", peer)
        if err != nil {
            log.Printf("Error connecting to peer %s: %s\n", peer, err)
            continue
        }
        defer conn.Close()

        n.sendMessage(conn, message)
    }
}

// sendMessage sends a message over the connection
func (n *Node) sendMessage(conn net.Conn, message Message) {
    encoder := json.NewEncoder(conn)
    if err := encoder.Encode(message); err != nil {
        log.Printf("Error sending message to %s: %s\n", conn.RemoteAddr(), err)
    }
}

// handleConnection handles incoming connections from peers
func (n *Node) handleConnection(conn net.Conn) {
    defer conn.Close()
    decoder := json.NewDecoder(conn)

    for {
        var message Message
        if err := decoder.Decode(&message); err != nil {
            log.Printf("Error decoding message: %s\n", err)
            return
        }

        log.Printf("Received message from %s: %+v\n", conn.RemoteAddr(), message)
        n.processMessage(message)
    }
}

// processMessage processes different types of messages
func (n *Node) processMessage(message Message) {
    switch message.Type {
    case "hello":
        log.Printf("Received hello from %s\n", message.Data)
    case "block":
        n.handleNewBlock(message.Data)
    default:
        log.Printf("Unknown message type: %s\n", message.Type)
    }
}

// ValidateTransaction validates a transaction
func (n *Node) ValidateTransaction(tx Transaction) bool {
    // 1. Check if sender has enough balance
    balance := n.GetBalance(tx.From)
    if balance < tx.Amount {
        log.Printf("Insufficient balance for transaction from %s\n", tx.From)
        return false
    }

    // 2. Verify signature
    if !n.VerifySignature(tx) {
        log.Printf("Invalid signature for transaction from %s\n", tx.From)
        return false
    }

    return true
}

// GetBalance retrieves the balance of a given address (dummy implementation)
func (n *Node) GetBalance(address string) int {
    // In a real implementation, this would check the blockchain or state database
    return 100 // Placeholder balance
}

// SignTransaction signs a transaction using the validator's private key
func (v *Validator) SignTransaction(tx *Transaction) error {
    hash := sha256.Sum256([]byte(fmt.Sprintf("%s:%s:%d", tx.From, tx.To, tx.Amount)))
    r, s, err := ecdsa.Sign(rand.Reader, v.PrivateKey, hash[:])
    if err != nil {
        return err
    }
    tx.Signature = fmt.Sprintf("%s:%s", r.String(), s.String())
    return nil
}

// VerifySignature verifies the signature of a transaction
func (n *Node) VerifySignature(tx Transaction) bool {
    parts := strings.Split(tx.Signature, ":")
    if len(parts) != 2 {
        return false
    }

    r, _ := new(big.Int).SetString(parts[0], 10)
    s, _ := new(big.Int).SetString(parts[1], 10)

    // Recreate the hash
    hash := sha256.Sum256([]byte(fmt.Sprintf("%s:%s:%d", tx.From, tx.To, tx.Amount)))

    // Assuming we have a way to get the public key from the address
    publicKey, err := n.GetPublicKey(tx.From)
    if err != nil {
        return false
    }

    return ecdsa.Verify(publicKey, hash[:], r, s)
}

// GetPublicKey retrieves the public key associated with an address (dummy implementation)
func (n *Node) GetPublicKey(address string) (*ecdsa.PublicKey, error) {
    // In a real implementation, this would retrieve the public key from a database or key store
    // Placeholder: return a public key generated from a known curve
    privateKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
    if err != nil {
        return nil, err
    }
    return &privateKey.PublicKey, nil
}

// AddTransaction adds a transaction to the pool
func (n *Node) AddTransaction(tx Transaction) {
    n.mu.Lock()
    defer n.mu.Unlock()

    if n.ValidateTransaction(tx) {
        n.TransactionPool = append(n.TransactionPool, tx)
        log.Printf("Transaction added: %+v\n", tx)
    } else {
        log.Printf("Transaction failed validation: %+v\n", tx)
    }
}

// ProposeBlock proposes a new block based on PoS
func (n *Node) ProposeBlock() {
    validator := n.SelectValidator()
    if validator == nil {
        log.Println("No validator selected")
        return
    }

    newBlock := Block{
        Index:        len(n.Blockchain) + 1,
        PreviousHash: n.calculateHash(len(n.Blockchain), "", "", time.Now(), 1), // Example hash calculation
        Creator:      validator.Address,
        Timestamp:    time.Now(),
        Difficulty:   1, // This will be dynamically adjusted
        Reward:       10, // Example reward value
        Data:         "Transactions: " + fmt.Sprintf("%+v", n.TransactionPool),
        Hash:         "",
        Votes:        make(map[string]bool),
    }

    // Add the block to the blockchain and reset the transaction pool
    n.Blockchain = append(n.Blockchain, newBlock)
    n.TransactionPool = []Transaction{} // Clear the transaction pool

    // Adjust difficulty
    n.AdjustDifficulty()

    newBlock.Hash = n.calculateHash(newBlock.Index, newBlock.PreviousHash, newBlock.Data, newBlock.Creator, newBlock.Timestamp, newBlock.Difficulty)

    // Broadcast new block
    n.Broadcast(Message{Type: "block", Data: newBlock.Hash})
}

// AdjustDifficulty dynamically adjusts the difficulty based on block generation time
func (n *Node) AdjustDifficulty() {
    if len(n.Blockchain) < 2 {
        return // Not enough blocks to adjust
    }

    // Get the generation time of the last two blocks
    lastBlock := n.Blockchain[len(n.Blockchain)-1]
    previousBlock := n.Blockchain[len(n.Blockchain)-2]

    // Calculate the time difference
    timeDiff := lastBlock.Timestamp.Sub(previousBlock.Timestamp).Seconds()

    // Set target generation time (e.g., 10 seconds)
    targetTime := 10.0

    if timeDiff < targetTime {
        // If generation time is too short, increase difficulty
        lastBlock.Difficulty++
    } else if timeDiff > targetTime {
        // If generation time is too long, decrease difficulty
        if lastBlock.Difficulty > 1 {
            lastBlock.Difficulty--
        }
    }
}

// SelectValidator selects a validator based on their stake
func (n *Node) SelectValidator() *Validator {
    totalStake := 0
    for _, validator := range n.Validators {
        totalStake += validator.Stake
    }

    randomValue := rand.Intn(totalStake)
    for _, validator := range n.Validators {
        if randomValue < validator.Stake {
            return &validator
        }
        randomValue -= validator.Stake
    }
    return nil
}

// validateBlock validates a new block
func (n *Node) validateBlock(block Block) bool {
    expectedHash := n.calculateHash(block.Index, block.PreviousHash, block.Data, block.Creator, block.Timestamp, block.Difficulty)
    return block.Hash == expectedHash
}

// calculateHash calculates the block hash
func (n *Node) calculateHash(index int, previousHash, data, creator string, timestamp time.Time, difficulty int) string {
    record := fmt.Sprintf("%d%s%s%s%d", index, previousHash, data, creator, difficulty)
    h := sha256.New()
    h.Write([]byte(record))
    return fmt.Sprintf("%x", h.Sum(nil))
}

// LoadConfig loads the configuration from a JSON file
func LoadConfig(filename string) (*Config, error) {
    data, err := ioutil.ReadFile(filename)
    if err != nil {
        return nil, err
    }
    var config Config
    if err := json.Unmarshal(data, &config); err != nil {
        return nil, err
    }
    return &config, nil
}

// Example usage
func main() {
    config, err := LoadConfig("config.json")
    if err != nil {
        log.Fatalf("Error loading config: %s\n", err)
    }

    node := NewNode(config.Address, config.Validators)

    for _, peer := range config.Peers {
        node.ConnectToPeer(peer)
    }

    // Example transaction
    tx := Transaction{
        From:   "validator_address",
        To:     "recipient_address",
        Amount: 10,
    }

    if err := node.Validators[0].SignTransaction(&tx); err != nil {
        log.Printf("Error signing transaction: %s\n", err)
        return
    }

    node.AddTransaction(tx)

    node.Start()
}
