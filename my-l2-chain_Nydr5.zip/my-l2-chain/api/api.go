package api

import (
    "github.com/gin-gonic/gin"
    "myproject/state"
)

// APIHandler 处理 API 请求
type APIHandler struct {
    DataStore *state.DataStore
}

// SetupRoutes 设置 API 路由
func (h *APIHandler) SetupRoutes(router *gin.Engine) {
    router.GET("/health", func(c *gin.Context) {
        c.JSON(200, gin.H{"status": "ok"})
    })

    router.GET("/api/status", func(c *gin.Context) {
        c.JSON(200, gin.H{"status": "API is running"})
    })

    // 添加其他 API 路由
}
