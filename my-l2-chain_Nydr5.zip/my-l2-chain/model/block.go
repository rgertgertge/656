package model

// Transaction represents a transaction structure
type Transaction struct {
    ID     string `json:"id"`
    From   string `json:"from"`
    To     string `json:"to"`
    Amount int    `json:"amount"`
}

// Block represents a simple block structure
type Block struct {
    Index        int          `json:"index"`
    PreviousHash string       `json:"previous_hash"`
    Transactions []Transaction `json:"transactions"`
    Hash         string       `json:"hash"`
}
