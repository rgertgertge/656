package main

import (
    "fmt"
    "log"
    "myproject/api"
    "myproject/config"
    "myproject/state"
    "github.com/gin-gonic/gin"
)

func main() {
    // 加载配置
    cfg, err := config.LoadConfig("config.json")
    if err != nil {
        log.Fatalf("Error loading config: %s", err)
    }

    router := gin.Default()

    // 创建数据存储实例
    ds := state.NewDataStore()

    // 创建 API 处理程序
    handler := &api.APIHandler{DataStore: ds}

    // 设置路由
    handler.SetupRoutes(router)

    // 启动服务器
    router.Run(fmt.Sprintf(":%d", cfg.Port))
}
package main

import (
    "fmt"
    "log"
    "myproject/api"
    "myproject/config"
    "myproject/state"
    "github.com/gin-gonic/gin"
)

func main() {
    // 加载配置
    cfg, err := config.LoadConfig("config.json")
    if err != nil {
        log.Fatalf("Error loading config: %s", err)
    }

    // 设置日志等级
    // 你可以使用不同的日志库来控制日志级别，这里只是示例
    log.SetOutput(os.Stdout)
    log.SetPrefix(fmt.Sprintf("[%s] ", cfg.LogLevel))

    router := gin.Default()

    // 创建数据存储实例
    ds := state.NewDataStore()

    // 创建 API 处理程序
    handler := &api.APIHandler{DataStore: ds}

    // 设置路由
    handler.SetupRoutes(router)

    // 启动服务器
    router.Run(fmt.Sprintf(":%d", cfg.Port))
}
