package server

import (
    "log"
    "github.com/gin-gonic/gin"
    "my-l2-chain/api"
)

func Start() {
    r := gin.Default()
    api.InitRoutes(r)

    if err := r.Run(":8080"); err != nil {
        log.Fatal(err)
    }
}
