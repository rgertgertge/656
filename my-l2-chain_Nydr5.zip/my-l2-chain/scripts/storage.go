package state

import (
    "encoding/json"
    "fmt"
    "io/ioutil"
    "sync"

    "my-l2-chain/model" // 更新为你的模块路径
)

// DataStore represents a simple data store for the L2 chain
type DataStore struct {
    mu       sync.Mutex
    Blocks   []model.Block       // 存储区块链
    Txns     []model.Transaction  // 存储交易记录
    Accounts map[string]int      // 存储账户余额
}

// NewDataStore initializes a new DataStore
func NewDataStore() *DataStore {
    return &DataStore{
        Blocks:   make([]model.Block, 0),
        Txns:     make([]model.Transaction, 0),
        Accounts: make(map[string]int),
    }
}

// AddBlock adds a new block to the blockchain
func (ds *DataStore) AddBlock(block model.Block) {
    ds.mu.Lock()
    defer ds.mu.Unlock()
    ds.Blocks = append(ds.Blocks, block)
}

// AddTransaction adds a new transaction
func (ds *DataStore) AddTransaction(txn model.Transaction) error {
    ds.mu.Lock()
    defer ds.mu.Unlock()

    // 简单的余额检查
    if ds.Accounts[txn.From] < txn.Amount {
        return fmt.Errorf("insufficient balance for address: %s", txn.From)
    }

    // 更新账户余额
    ds.Accounts[txn.From] -= txn.Amount
    ds.Accounts[txn.To] += txn.Amount
    ds.Txns = append(ds.Txns, txn)
    return nil
}

// SaveBlocks saves the blockchain to a file
func (ds *DataStore) SaveBlocks(filename string) error {
    ds.mu.Lock()
    defer ds.mu.Unlock()

    data, err := json.Marshal(ds.Blocks)
    if err != nil {
        return fmt.Errorf("error marshalling blocks: %s", err)
    }
    return ioutil.WriteFile(filename, data, 0644)
}

// LoadBlocks loads the blockchain from a file
func (ds *DataStore) LoadBlocks(filename string) error {
    ds.mu.Lock()
    defer ds.mu.Unlock()

    data, err := ioutil.ReadFile(filename)
    if err != nil {
        return fmt.Errorf("error reading blocks from file: %s", err)
    }
    return json.Unmarshal(data, &ds.Blocks)
}

// SaveTransactions saves transactions to a file
func (ds *DataStore) SaveTransactions(filename string) error {
    ds.mu.Lock()
    defer ds.mu.Unlock()

    data, err := json.Marshal(ds.Txns)
    if err != nil {
        return fmt.Errorf("error marshalling transactions: %s", err)
    }
    return ioutil.WriteFile(filename, data, 0644)
}

// LoadTransactions loads transactions from a file
func (ds *DataStore) LoadTransactions(filename string) error {
    ds.mu.Lock()
    defer ds.mu.Unlock()

    data, err := ioutil.ReadFile(filename)
    if err != nil {
        return fmt.Errorf("error reading transactions from file: %s", err)
    }
    return json.Unmarshal(data, &ds.Txns)
}

// SaveAccounts saves account balances to a file
func (ds *DataStore) SaveAccounts(filename string) error {
    ds.mu.Lock()
    defer ds.mu.Unlock()

    data, err := json.Marshal(ds.Accounts)
    if err != nil {
        return fmt.Errorf("error marshalling accounts: %s", err)
    }
    return ioutil.WriteFile(filename, data, 0644)
}

// LoadAccounts loads account balances from a file
func (ds *DataStore) LoadAccounts(filename string) error {
    ds.mu.Lock()
    defer ds.mu.Unlock()

    data, err := ioutil.ReadFile(filename)
    if err != nil {
        return fmt.Errorf("error reading accounts from file: %s", err)
    }
    return json.Unmarshal(data, &ds.Accounts)
}
