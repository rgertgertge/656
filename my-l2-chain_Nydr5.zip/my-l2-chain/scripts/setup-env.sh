#!/bin/bash
# Setup environment for development

echo "Setting up environment..."
# Install dependencies, setup databases, etc.
