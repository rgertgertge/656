#!/bin/bash
# Script to deploy smart contracts

# Deploy ERC20
echo "Deploying ERC20 contract..."
# Add deployment commands here (e.g., using truffle or hardhat)

# Deploy NFT
echo "Deploying NFT contract..."
# Add deployment commands here
